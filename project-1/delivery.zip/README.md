
# Trabalho de programação

## Grupo

202004175 - Diogo Alexandre da Costa Melo Moreira da Fonte

## Tarefas realizadas

Todos os testes em color_test.cpp passam.
Classe rgb::color implementada com sucesso.
color.hpp documentado, mas não consigo gerar a documentação.

Todos os testes em image_test.cpp passam.
Classe rgb::image implementada com sucesso.
image.hpp documentado, mas não consigo gerar a documentação.

Todos os testes em script_test.cpp passam.
Classe rgb::script implementada com sucesso.
script.hpp documentado, mas não consigo gerar a documentação.
É detetado um warning em png.cpp pelos sanitizers que não consigo resolver.